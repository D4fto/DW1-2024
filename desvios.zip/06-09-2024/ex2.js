console.log(1)
console.log(2)

if (condicao1) {
    console.log('a')
} else {
    if (condicao2) {
        if (condicao3) {
            console.log('b')
        } else {
            console.log('c')
        }
    } else {
        console.log('d')
    }
}

console.log(3)
console.lo(4)