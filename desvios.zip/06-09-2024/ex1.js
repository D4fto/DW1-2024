
console.log(1)
console.log(2)

if (condicao1) {
    if (condicao2) {
        console.log('a')
    } else {
        console.log('b')
    }
} else {
    if (condicao3) {
        console.log('c')
    } else {
        console.log('d')
    }
}

console.log(3)
console.log(4)