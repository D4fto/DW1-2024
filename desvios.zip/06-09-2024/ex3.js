
if (condicao1) {
    if (condicao2) {
        if (condicao3) {
            console.log('a')
        } else {
            console.log('b')
        }
    } else {
        if (condicao4) {
            console.log('c')
        } else {
            console.log('d')
        }
    }
} else {
    if (condicao5) {
        if (condicao6) {
            console.log('e')
        } else {
            console.log('f')
        }
    } else {
        if (condicao7) {
            console.log(g)
        } else {
            console.log('h')
        }
    }
}