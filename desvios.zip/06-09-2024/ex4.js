let variavel = '3'
switch(variavel){
    case('1'):
        console.log('a');
        break
    case('2'):
        console.log('b');
        break
    case('3'):
        console.log('c');
        break
    case('4'):
        console.log('d');
        break
    case('5'):
        console.log('e')
        break
    case('6'):
        console.log('f');
        break
    case('7'):
        console.log('g');
        break
    case('8'):
        console.log('h');
        break
    
}